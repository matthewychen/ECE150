#include <iostream>

int main() {
  std::cout << "     p<" << std::endl << "\"___/" << std::endl << " \\=/" << std::endl << "  \\_" << std::endl;
  return 0;
}