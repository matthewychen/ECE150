#include <iostream>
// \b is backspace or back-delete
// \t is tab
// \f is a curse on all who use it
int main() {
  std::cout << "     p<\n";
  std::cout << "\"___/\b";
  std::cout << " \\=/\f";
  std::cout << "  \\_\t";
  return 0;
}