#include <iostream>

int main() {
  std::cout << "   ";
  std::cout << "  p<";
  std::cout << std::endl;
  std::cout << "\"_";
  std::cout << "_/";
  std::cout << std::endl;
  std::cout << " \\=";
  std::cout << "/";
  std::cout << std::endl;
  std::cout << "  ";
  std::cout << "\\_";
  std::cout << std::endl;
  return 0;
}