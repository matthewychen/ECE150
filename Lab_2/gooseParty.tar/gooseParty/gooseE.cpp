#include <iostream>
// never use \f
int main() {
  std::cout << "     p<\f";
  std::cout << "\"___/\f";
  std::cout << " \\=/\f";
  std::cout << "  \\_\f";
  return 0;
}