#include <iostream>
// \" is " (double quote)
// \\ is \ (backslash)
int main() {
  std::cout << "     p<" << std::endl;
  std::cout << "\"___/"  << std::endl;
  std::cout << " \\=/"   << std::endl;
  std::cout << "  \\_"   << std::endl;
  return 0;
}